<?php
session_start();
include('connect.php');
$a = $_POST['fname'];
$k = $_POST['lname'];
$e = $_POST['dob'];
$b = $_POST['education'];
$c = $_POST['gender'];
$d = $_POST['teacherphone'];
$m = $_POST['empydate'];
$f = $_POST['teacherlevel'];
$j = $_POST['frmone'];
$n = $_POST['frmtwo'];
$y = $_POST['frmthree'];
$p = $_POST['frmfour'];

// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO teachers (fname,lname,dob,gender,phone,education,EmploymentDate,frmone,frmtwo,frmthree,frmfour) VALUES (:a,:k,:e,:b,:c,:d,:m,:f,:j,:n,:y,:p)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':k'=>$k,':e'=>$e,':b'=>$b,':c'=>$c,':d'=>$d,':m'=>$m,':f'=>$f,':j'=>$j,':n'=>$n,':y'=>$y,':p'=>$p));
header("location: teachers.php");

	//}


?>