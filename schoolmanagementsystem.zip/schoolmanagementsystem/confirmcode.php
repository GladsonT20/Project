<?php
    $confirmcode="Q1Ea2";
    $codeCheck = $_POST["code"];
    if($codeCheck == $confirmcode){
        header("location: register.php");
    }
    else{
          header("location: provecode.php");
    }

    ?> 