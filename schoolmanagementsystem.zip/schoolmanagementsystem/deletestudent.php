<?php
	include('connect.php');
	$stdId=$_GET['stdId'];
	$result = $db->prepare("DELETE FROM student WHERE stdId= :stdId");
	$result->bindParam(':stdId', $stdId);
	$result->execute();
	
	header ("location: students.php");
?>