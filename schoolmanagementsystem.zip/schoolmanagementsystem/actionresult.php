<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<center>
	<br>
	<br>
<a href="createclass.php" style="float: right;"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px; background-color: #7386D5; font-weight: bold;" /><i class="icon-plus-sign icon-large"></i> Add Class</button></a>
<?php
     include('connect.php');
	$result = $db->prepare("SELECT * FROM class");
	$result->execute();
	if($result->rowCount() > 0)
{
	?>
	<input type="text" style="height:35px; color:#222; width: 30%; float: left;" name="filter" value="" id="filter" placeholder="Search Class..." autocomplete="off" />
<table class="hoverTable" id="resultTable" data-responsive="table" style="text-align: left;" >
	<thead>
	<tr>
			<th width="6%" style="font-size:16px; font-weight: bold;"> Class / Year</th>
			<th width="5%" style="font-size:16px; font-weight: bold;"> Created at </th>
			<th width="15%" style="font-size:16px; font-weight: bold;"> Action </th>
		</tr>
	</thead>
	<tbody>
	<?php
		for($i=0; $row = $result->fetch(); $i++){
?>
            <td><?php echo $row['classname']; ?>-<?php echo $row['year']; ?></td>
			<td><?php echo $row['created_at']; ?></td>
			<td><a title="Click to view the Student" href="viewclass.php?id=<?php echo $row['id']; ?>"><button class="btn btn-success btn-primary"style="width: 30%;"><i class="icon-search" ></i> View Student</button> </a>
			<a  href="resultadd.php?id=<?php echo $row['id']; ?>" title="Click To Add Result"><button class="btn btn-primary" style="width: 36%;"><i class="icon-plus-sign"></i> Add Result</button></a></td>
			</tr>
<br>
			
</center>

</div>
<?php
}
?>
</tbody>
</table>
<?php
}
else{
	?>
	<h4>No Student assign to this class</h4>
<?php
}
?>
<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'stdId=' + del_id;
 if(confirm("Sure you want to delete this Student? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deletestdntinclass.php",
   data: info,
   success: function(){
    document.location.reload(true);
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
<?php include('footer.php');?>