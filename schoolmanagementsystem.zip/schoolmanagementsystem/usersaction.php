<div class="contentheader">
			<?php 
			include('connect.php');
				$result = $db->prepare("SELECT * FROM users WHERE id>1");
				$result->execute();
				$rowcount = $result->rowcount();
			?>
			
		
				<div style="text-align:center; margin-top: 15px;" >
			Total Number of Users:  <font color="green" style="font:bold 22px 'Aleo';">[<?php echo $rowcount;?>]</font>
			</div>
<input type="text" style="height:35px; color:#222;" name="filter" value="" id="filter" placeholder="Search User..." autocomplete="off" />
<a href="adduser.php"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px; background-color: #2A93D5;" /><i class="fa fa-user-plus" aria-hidden="true"></i> Add User</button></a><br><br>
<table class="hoverTable" id="resultTable" data-responsive="table" style="text-align: left;">
	<thead>
		<tr>
			<th width="15%"> Username </th>
			<th width="10%"> Role</th>
			<th width="5%"> Assigned Class </th>
			<th width="15%"> Action </th>
		</tr>
	</thead>
	<tbody>
		
			<?php
			
				include('connect.php');
				$result = $db->prepare("SELECT * FROM users WHERE id>1");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
				
			?>
		
<td><?php echo $row['username']; ?></td>
			<td><?php echo $row['role']; ?></td>
			<td><?php //echo $row['yoa']; ?></td>
			<td>
			<a  title="Click to assign class" href="editstudent.php?stdId=<?php echo $row['stdId']; ?>"><button class="btn btn-warning btn-mini"><i class="icon-edit"></i>Add to Class</button> </a>
			<a  href="deletestudent.php" id="<?php echo $row['stdId']; ?>" class="delbutton" title="Click To Delete"><button class="btn btn-danger btn-mini"><i class="icon-trash"></i> Delete</button></a></td>
			</tr>
			<?php
				}
			?>
		
		
		
	</tbody>
</table>
<div class="clearfix"></div>

<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'stdId=' + del_id;
 if(confirm("Sure you want to delete this Student? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deletestudent.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
