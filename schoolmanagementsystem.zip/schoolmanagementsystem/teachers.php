<html>
<head>
<title>
Student Information System
</title>

<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 <link href="main/css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="main/css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="main/css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="main/css/bootstrap-responsive.css" rel="stylesheet">

<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
<!--sa poip up-->
<script src="jeffartagame.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>
</head>
<body>
<?php include('navfixed.php');?>
<div class="container-fluid">
      <div class="row-fluid">
	<div class="span2">
                <?php include('adminsidemenu.php');?>
        </div><!--/span-->
	<div class="span10">
	<div class="contentheader">
			<i class="icon-table"></i> Teachers
			</div>
			<ul class="breadcrumb">
			<li><a href="welcome.php">Dashboard</a></li> /
			<li class="active">Teachers</li>
			</ul>


<div style="margin-top: -19px; margin-bottom: 21px;">
<a  href="welcome.php"><button class="btn btn-default btn-large" style="float: left;"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>
			<?php 
			include('connect.php');
				$result = $db->prepare("SELECT * FROM subject ORDER BY Code DESC");
				$result->execute();
				$rowcount = $result->rowcount();
			?>
			
		
				<div style="text-align:center;">
			Total Number of Teachers:  <font color="green" style="font:bold 22px 'Aleo';">[<?php echo $rowcount;?>]</font>
			</div>
			
			
</div>


<input type="text" style="height:35px; color:#222;" name="filter" value="" id="filter" placeholder="Search Teachers..." autocomplete="off" />
<a href="#"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px;" /><i class="icon-plus-sign icon-large"></i> Add Teachers</button></a><br><br>
<table class="hoverTable" id="resultTable" data-responsive="table" style="text-align: left;">
			<caption>Teachers with corresponding Subject on class</caption>
<thead>
		<tr>
			<th width="10%"> CLASS</th>
			<th width="10%" > SUBJECT</th>
			<th width="10%" > TEACHER </th>
			<th width="15%"> Action </th>
		</tr>
	</thead>
	<tbody>
		
			<?php
			
				include('connect.php');
				$result = $db->prepare("SELECT * FROM subject ORDER BY class");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
				
			?>

			<td><?php echo $row['class']; ?></td>
			<td><?php echo $row['NameOfSubject']; ?><br></td>
			<td><?php echo $row['teacher']; ?><br></td>
			<td><a title="Click to view the Teacher" href="viewteacher.php?teacher=<?php echo $row['teacher']; ?>"><button class="btn btn-success btn-mini"><i class="icon-search"></i> View</button> </a>
			<a  title="Click to edit the Teacher" href="editsubject.php?Code=<?php echo $row['Code']; ?>"><button class="btn btn-warning btn-mini"><i class="icon-edit"></i> Edit</button> </a>
			<a  href="deleteteacher.php?Code=<?php echo $row['Code']; ?>" class="delbutton" title="Click To Delete"><button class="btn btn-danger btn-mini"><i class="icon-trash"></i> Delete</button></a></td>
			</tr>
			<?php
				}
			?>
		
		
		
	</tbody>
</table>
<div class="clearfix"></div>
</div>
</div>
</div>

<script src="js/jquery.js"></script>
</body>
<?php include('footer.php');?>

</html>