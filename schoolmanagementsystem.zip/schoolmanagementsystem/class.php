<html>
<head>
	<title>
		Student Record Management System
	</title>

	<?php 
	// Initialize the session
	session_start();

	// Check if the user is logged in, if not then redirect him to login page
	if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
	header("location: login.php");
	exit;
}
?>
<link href="css/bootstrap.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">

<link rel="stylesheet" href="css/font-awesome.min.css">
<style type="text/css">
	body {
		padding-top: 60px;
		padding-bottom: 40px;
	}
	.sidebar-nav {
		padding: 9px 0;
	}
</style>
<link href="css/bootstrap-responsive.css" rel="stylesheet">

<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
<!--sa poip up-->
<script src="jeffartagame.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('a[rel*=facebox]').facebox({
			loadingImage : 'src/loading.gif',
			closeImage   : 'src/closelabel.png'
		})
	})
</script>
</head>
<body>
	<?php include('navfixed.php');?>
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span2">
				<?php include('adminsidemenu.php');?>
				<!--/.well -->
			</div><!--/span-->
			<div class="span10">
				<div class="contentheader">
					<i class="icon-table"></i> Add Subject
				</div>
				<ul class="breadcrumb">
					<li><a href="welcome.php">Dashboard</a></li> /
					<li class="active">Add Subject</li>
				</ul>


				<div style="margin-top: -19px; margin-bottom: 21px;">
					<a  href="welcome.php"><button class="btn btn-default btn-large" style="float: left;"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>
					<form action="savesubject.php" method="post" enctype="multipart/form-data">
						<center><h4><i class="icon-edit icon-large"></i> Add New Subjects	</h4></center>
						<hr><center>
							<div id="ac">
								<span style=" width: 150px;">Subject Name : </span><input type="text" style="width:265px; height:30px;"  name="subjectname" Required /><br>
								<span style=" width: 150px;">Class: </span><select name="classname" style="width:265px; height:30px; margin-left:-5px;" >
									<option>Choose Class</option>
									<option>Form One</option>
									<option>Form Two</option>
									<option>Form Three</option>
									<option>Form Four</option>
									<option>Form Five</option>
									<option>Form Six</option>
								</select><br>
								<span style=" width: 150px;">Choose Teacher:</span>
							<input list="teacher" name="subjectteacher" style="width:265px; height:30px; margin-left:-5px;">
							<datalist id="teacher">
								<?php

									include('connect.php');
									$result = $db->prepare("SELECT fname FROM teachers");
									$result->execute();
									for($i=0; $row = $result->fetch(); $i++){

									?>
								<option value="<?php echo $row['fname'];?>">
										<?php
								}
								?>
												</datalist>
												<br>
												<br>
												<div >

													<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
												</div>
											</div>
										</form>
									</center>
								</body>
								<?php include('footer.php');?>

								</html>