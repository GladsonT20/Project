<div class="contentheader">
<div style="margin-bottom: 21px;">
	<center>
					<form action="savest.php" method="post" enctype="multipart/form-data">
						<center><h4><i class="icon-edit icon-large"></i>Adding Student on <?php echo $classname; ?> / <?php echo $year;?></h4></center>
						<hr>
								<h4>Student Registration Number:</h4><input list="reg" name="stdId" style="width:265px; height:30px; margin-left:-5px;" required="">
								<datalist id="reg">
									<option selected="selected" disabled="disabled" value="">Please Select</option>
									<?php
									include('connect.php');
									$result = $db->prepare("SELECT stdId FROM student");
									$result->execute();
									for($i=0; $row = $result->fetch(); $i++){
										?>			
							<option value="<?php echo $row['stdId'];?>"><?php echo $row['stdId'];?></option>
						         <?php } ?>
						        </datalist>
						         <br>
						           <br>
						             <br>
								<div >

									<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Add Student</button>
								</div>
							</div>
							</div>
						
					</form>
				</center>
			</div>
			</div>
	</div>