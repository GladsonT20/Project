<?php
session_start();
include('connect.php');
$cn = $_POST['classname'];
$cy= $_POST['year'];
// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO class (classname, year) VALUES (:cn, :cy)";
$q = $db->prepare($sql);
$q->execute(array(':cn'=>$cn,':cy'=>$cy));
header("location: classes.php");
?>