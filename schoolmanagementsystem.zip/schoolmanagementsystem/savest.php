<?php
session_start();
include('connect.php');
$cn = $_POST['stdId'];
$cy= $_GET['classid'];
// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO tblclasses (classid, studentid) VALUES (:cy, :cn)";
$q = $db->prepare($sql);
$q->execute(array(':cy'=>$cy,':cn'=>$cn));
header("location: viewclass.php?id=$cy");
?>