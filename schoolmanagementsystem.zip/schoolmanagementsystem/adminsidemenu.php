<div class="sidenav">
  <a class="dropdown-btn" href="home.php"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;HOME&nbsp;&nbsp;</a>
  <br>
  <button class="dropdown-btn" ><i class="fa fa-users" aria-hidden="true"></i>&nbsp;STUDENTS</button>
  <div class="dropdown-container" >
    <a href="addstudent.php">Add</a>
    <a href="students.php">Manage</a>
  </div>
  <button class="dropdown-btn"><i class="menu-icon fa fa-th"></i>&nbsp;CLASS
  </button>
  <div class="dropdown-container">
    <a href="createclass.php">create</a>
    <a href="classes.php">Manage</a>
  </div>
  <button class="dropdown-btn"><i class="menu-icon fa fa-th"></i>&nbsp;SUBJECT
  </button>
  <div class="dropdown-container">
    <a href="addsubject.php">Create</a>
    <a href="subject.php">Manage</a>
  </div>
  <button class="dropdown-btn"><i class="menu-icon fa fa-th"></i>&nbsp;RESULT
  </button>
  <div class="dropdown-container">
    <a href="result.php">Add</a>
    <a href="mngresult.php">Manage</a>
  </div>
  <button class="dropdown-btn"><i class="menu-icon fa fa-th"></i>&nbsp;USERS
  </button>
  <div class="dropdown-container">
    <a href="adduser.php">Add</a>
    <a href="user.php">Manage</a>
  </div>
  <a href="#contact">Help</a>
</div>
