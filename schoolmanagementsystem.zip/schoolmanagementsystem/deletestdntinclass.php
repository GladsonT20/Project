<?php
	include('connect.php');
	$id=$_GET['studentid'];
	$classid=$_GET['classid'];
	//echo $id;
	//echo $classid;
	$result = $db->prepare("DELETE FROM tblclasses WHERE studentid='$id' AND classid='$classid'");
	//$result->bindParam(':stdid', $id, PDO::PARAM_STR, 12);
	//$result->bindParam(':clsid', $classid, PDO::PARAM_INT);
	$result->execute();
	header ("location: viewclass.php?id=$classid");
?>