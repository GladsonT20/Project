<?php
	include('connect.php');
	$id=$_GET['stubjectid'];
	$result = $db->prepare("DELETE FROM subject WHERE stubjectid=:id");
	$result->bindParam(':id', $id);
	$result->execute();
	
	header ("location: subject.php");
?>