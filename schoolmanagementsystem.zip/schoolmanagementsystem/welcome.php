<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
$role = $_SESSION["role"]
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SRMS</title>
  <link href="main/css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="main/css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="main/css/font-awesome.min.css">
    <style type="text/css">
    
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="main/css/bootstrap-responsive.css" rel="stylesheet">
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>

    <?php include('navfixed.php');?>
    <?php
$position=$role;
if($position=='teacher') {
?>
<div class="container-fluid">
      <div class="row-fluid">
    <div class="span2">
          <div class="well sidebar-nav">
              <ul class="nav nav-list">
              <li class="active"><a href="welcome.php"><i class="icon-home icon-2x"></i> Home</a></li>
              <li><a href="adddetail.php"><i class="icon-file icon-2x"></i>Add Your Detail</a></li>
            <li><a href="Viewdetails.php"><i class="icon-file icon-2x"></i>View Your Detail</a></li>
            <li><a href="#"><i class="icon-user icon-2x"></i>Result</a></li>
            <br><br> 
                
                </ul>             
          </div><!--/.well -->
        </div><!--/span-->
    <div class="span10">
    <div class="contentheader">
            <ul class="breadcrumb">
            <li class="active">Dashboard</li>
            </ul>
<div id="mainmain">
<p>Main content Here</p> 

<?php
}
if($position=='admin') {
?>
    
    <div class="container-fluid">
      <div class="row-fluid">
    <div class="span2">
<?php include('adminsidemenu.php');?>
        </div><!--/span-->
    <div class="span10">
    <div class="contentheader">
            <ul class="breadcrumb">
            <li class="active">Dashboard</li>
            </ul>
<div id="mainmain">
<p>Main content Here</p> 
<?php
}
?>


<div class="clearfix"></div>
</div>
</div>
</div>
</div>
</div>
</body>
<?php include('footer.php'); ?>
</html>