<?php
session_start();
 $_SESSION["code"] = true;

 
// Check if the user is already logged in, if yes then redirect him to welcome page
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Security</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 40%; 
            margin-left: 30%;
            border:1px solid;
            border-radius: 10%;
            border-top-style: solid;
        }
    </style>
</head>
<body>
    <div class="wrapper" ><center>
        <p>Please enter security code provide to Staff member.</p>
        <form action="confirmcode.php" method="post">    
                <input type="text" name="code" class="form-control" placeholder="Enter code">
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Send">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
        </center>
    </div>   
</body>
</html>