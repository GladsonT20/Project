<div class="contentheader">
			<?php 
			include('connect.php');
				$result = $db->prepare("SELECT * FROM student ORDER BY stdId DESC");
				$result->execute();
				$rowcount = $result->rowcount();
			?>
			
		
				<div style="text-align:center; margin-top: 15px;" >
			Total Number of Students:  <font color="green" style="font:bold 22px 'Aleo';">[<?php echo $rowcount;?>]</font>
			</div>
<input type="text" style="height:35px; color:#222;" name="filter" value="" id="filter" placeholder="Search Students..." autocomplete="off" />
<a href="addstudent.php"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px; background-color: #194C33;" /><i class="fa fa-user-plus" aria-hidden="true"></i>Add Student</button></a><br><br>
<table class="hoverTable" id="resultTable" data-responsive="table" style="text-align: left;">
	<thead>
		<tr>
			<th width="10%"> Student ID</th>
			<th width="15%"> Full Name </th>
			<th width="10%"> Date of Birth </th>
			<th width="5%"> Gender </th>
			<th width="5%"> Admittion Year </th>
			<th width="10%"> Parent Phone </th>
			<th width="15%"> Action </th>
		</tr>
	</thead>
	<tbody>
		
			<?php
			
				include('connect.php');
				$result = $db->prepare("SELECT * FROM student ORDER BY stdId DESC");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
				
			?>
		
<td><?php echo $row['stdId']; ?></td>
			<td><?php echo $row['fname']; ?></td>
			<td><?php echo $row['DOB']; ?></td>
			<td><?php echo $row['gender']; ?></td>
			<td><?php echo $row['yoa']; ?></td>
			<td><?php echo $row['ppn']; ?></td>
			<td><a title="Click to view the Student" href="viewstudent.php?stdId=<?php echo $row['stdId']; ?>"><button class="btn btn-success btn-mini"><i class="icon-search"></i> View</button> </a>
			<a  title="Click to edit the Student" href="editstudent.php?stdId=<?php echo $row['stdId']; ?>"><button class="btn btn-warning btn-mini"><i class="icon-edit"></i> Edit</button> </a>
			<a  href="deletestudent.php" id="<?php echo $row['stdId']; ?>" class="delbutton" title="Click To Delete"><button class="btn btn-danger btn-mini"><i class="icon-trash"></i> Delete</button></a></td>
			</tr>
			<?php
				}
			?>
		
		
		
	</tbody>
</table>
<div class="clearfix"></div>

<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'stdId=' + del_id;
 if(confirm("Sure you want to delete this Student? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deletestudent.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
