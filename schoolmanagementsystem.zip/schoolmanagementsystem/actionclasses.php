<div class="contentheader">
			<?php 
			include('connect.php');
				$result = $db->prepare("SELECT * FROM class ORDER BY id DESC");
				$result->execute();
				$rowcount = $result->rowcount();
			?>
			
		
				<div style="text-align:center; margin-top: 15px;" >
			Total Number of Class:  <font color="green" style="font:bold 22px 'Aleo';">[<?php echo $rowcount;?>]</font>
			</div>
<input type="text" style="height:35px; color:#222;" name="filter" value="" id="filter" placeholder="Search Class..." autocomplete="off" />
<a href="createclass.php"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px; background-color: #2d895b;" /><i class="icon-plus-sign icon-large"></i> Create Class</button></a><br><br>
<table class="hoverTable" id="resultTable" data-responsive="table" style="text-align: left;">
	<thead>
		<tr>
			<th width="10%"> Class Name</th>
			<th width="20%"> Year </th>
			<th width="10%"> Created at </th>
			<th width="15%"> Action </th>
		</tr>
	</thead>
	<tbody>
		
			<?php
			
				include('connect.php');
				$result = $db->prepare("SELECT * FROM class ORDER BY created_at DESC");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
				
			?>
		
			<td><?php echo $row['classname']; ?></td>
			<td><?php echo $row['year']; ?></td>
			<td><?php echo $row['created_at']; ?></td>
			<td><a title="Click to view the Class" href="viewclass.php?id=<?php echo $row['id']; ?>"><button class="btn btn-success btn-mini"><i class="icon-search"></i> View Class</button> </a>
			<a  href="deleteclass.php" id="<?php echo $row['id']; ?>" class="delbutton" title="Click To Delete"><button class="btn btn-danger btn-mini"><i class="icon-trash"></i> Delete Class</button></a></td>
			</tr>
			<?php
				}
			?>
		
		
		
	</tbody>
</table>
<div class="clearfix"></div>

<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
 if(confirm("Sure you want to delete this Class? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deleteclass.php",
   data: info,
   success: function(){
   	 document.location.reload(true);
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
