<?php
session_start();
include('connect.php');
    $id=$_SESSION['id'];
	$marks=$_POST['mark'];
	$updatemarks="UPDATE result  SET marks=? WHERE id=?";
	$qu=$db->prepare($updatemarks);
	$qu->execute(array($marks, $id));
	header("location: mngresult.php");
	//echo $id;
	//echo $marks;
	?>