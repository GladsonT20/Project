<?php
session_start();
include('connect.php');
$sn = $_POST['subjectname'];
$cn = $_POST['classid'];
// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO subject (NameofSubject,classid) VALUES (:sn,:cn)";
$q = $db->prepare($sql);
$q->execute(array(':sn'=>$sn,':cn'=>$cn));
header("location: subject.php");

	//}


?>