<?php
session_start();
include('connect.php');
$cn = $_POST['classname'];
$st= $_POST['student'];
// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO class (classname,StudentName) VALUES (:cn,:st)";
$q = $db->prepare($sql);
$q->execute(array(':cn'=>$cn,':st'=>$st));
header("location: studentsinclass.php");

	//}


?>