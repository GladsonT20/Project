<div class="contentheader">
			<?php 
			include('connect.php');
				$result = $db->prepare("SELECT * FROM subject ORDER BY stubjectid DESC");
				$result->execute();
				$rowcount = $result->rowcount();
			?>
			
		
				<div style="text-align:center; margin-top: 15px;" >
			Total Number of Subject:  <font color="green" style="font:bold 22px 'Aleo';">[<?php echo $rowcount;?>]</font>
			</div>
<input type="text" style="height:35px; color:#222;" name="filter" value="" id="filter" placeholder="Search Subject..." autocomplete="off" />
<a href="addsubject.php"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px; background-color: #305F72;" /><i class="icon-plus-sign icon-large"></i> Add Subject</button></a><br><br>
<table class="hoverTable" id="resultTable" data-responsive="table" style="text-align: left;">
	<thead>
		<tr>
			<th width="10%"> Subject</th>
			<th width="20%"> Class </th>
			<th width="15%"> Action </th>
		</tr>
	</thead>
	<tbody>
		
			<?php
			
				include('connect.php');
				$result = $db->prepare("SELECT * FROM subject ORDER BY stubjectid DESC");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
				
			?>
			<td><?php echo $row['NameOfSubject']; ?></td>
			<?php
               $results = $db->prepare("SELECT * FROM class WHERE id= :id");
	            $results->bindParam(':id', $row['classid']);
			     $results->execute();
	for($i=0; $rows = $results->fetch(); $i++){
?>
			<td><?php echo $rows['classname']; ?> : <?php echo $rows['year']; ?></td>
			<td><a  href="deletesubject.php" id="<?php echo $row['stubjectid']; ?>" class="delbutton" title="Click To Delete"><button class="btn btn-danger btn-mini"><i class="icon-trash"></i> Delete</button></a></td>
			</tr>
			<?php
				}
			}
			?>
		
		
		
	</tbody>
</table>
<div class="clearfix"></div>

<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'stubjectid=' + del_id;
 if(confirm("Sure you want to delete this Student? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deletesubject.php",
   data: info,
   success: function(){
   document.location.reload(true);
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
