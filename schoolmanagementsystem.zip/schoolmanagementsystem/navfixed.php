 
 <div class="navbar navbar-inverse navbar-fixed-top" style="background-color: rgb(51 153 102);>
      <div class="navbar-inner" style="background-color:rgb(51 153 102);>
        <div class="container-fluid" style="background-color: rgb(51 153 102)">
          <a class="brand" href="home.php" style="font-size: 30px;"><b>Student Academic Management System </b></a>
          <br>
            <ul class="nav pull-right">
              <li><a><i class="fa fa-user" aria-hidden="true"></i> Welcome:<strong> <?php echo htmlspecialchars($_SESSION["username"]); ?></strong></a></li>
			 <li><a><i class="fa fa-address-card" aria-hidden="true"></i>&nbsp;Profile</a></li>
              <li><a href="logout.php"><font color="red"><i class="fa fa-power-off" aria-hidden="true"></i></font> Log Out</a></li>
            </ul>
        </div>
      </div>
    </div>
	