<html>
<head>
<title>
Student Information System
</title>

<?php 
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 <link href="css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.7/css/all.css">


<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
<!--sa poip up-->
<script src="jeffartagame.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>
</head>	
<body>
<?php include('navfixed.php');?>
<div class="container-fluid">
      <div class="row-fluid">
	<div class="span2">
          <div class="well sidebar-nav">
             <ul class="nav nav-list">
              <li><a href="welcome.php"><i class="icon-home icon-2x"></i> Home</a></li>
              <li ><a href="teachers.php"><i class="icon-group icon-2x"></i>Manage Teachers</a></li>
            <li><a href="addsubject.php"><i class="icon-user icon-2x"></i>Add Subject</a></li>
            <li class="active"><a href="students.php"><i class="icon-group icon-2x"></i>Manage Students</a></li>
            <li><a href="addstudent.php"><i class="icon-user icon-2x"></i>Add Student</a></li>
            <br><br> 
                
                </ul>           
          </div><!--/.well -->
        </div><!--/span-->
	<div class="span10">
	<div class="contentheader">
			<i class="icon-table"></i> Teachers
			</div>
			<ul class="breadcrumb">
			<li><a href="welcome.php">Dashboard</a></li> /
			<li class="active">Teachers</li>
			</ul>


<div style="margin-top: -19px; margin-bottom: 21px;">
<a  href="welcome.php"><button class="btn btn-default btn-large" style="float: left;"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>
<center><?php
	include('connect.php');
	$id=$_GET['Code'];
	$result = $db->prepare("SELECT * FROM subject WHERE Code= :id");
	$result->bindParam(':id', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveeditsubject.php" method="post" enctype="multipart/form-data">
<center><h4><i class="icon-edit icon-large"></i> Edit Teacher</h4></center>
<hr>
<div id="ac">
<input type="hidden" style="width:265px; height:30px;"  name="code" value="<?php echo $row['Code']; ?>"/><br>
<span>Subject : </span><input type="text" style="width:265px; height:30px;"  name="subject" value="<?php echo $row['NameOfSubject']; ?>" /><br>
<span>Class: </span><select name="classname" style="width:265px; height:30px; margin-left:-5px;"  >
  <option><?php echo $row['class']; ?></option>
    <option>Form One</option>
  <option>Form Two</option>
  <option>Form Three</option>
  <option>Form Four</option>
  <option>Form Five</option>
  <option>Form Six</option>
</select><br>
<span>Teacher:</span><select name="subjectteacher" style="width:265px; height:30px; margin-left:-5px;">
  <option><?php echo $row['teacher']; ?></option>
    <?php
      
        include('connect.php');
        $result = $db->prepare("SELECT fname FROM teachers");
        $result->execute();
        ;

        for($i=0; $row = $result->fetch(); $i++){
        
      ?><option>

       <?php echo $row['fname'];
      ?></option>
      <?php
        }
      ?>
</select><br>
<div>

<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save Changes</button>
</div>
</div>
</form>
<?php
}
?>
</center>

<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
 if(confirm("Sure you want to delete this Student? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deletestudent.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
</body>
<?php include('footer.php');?>

</html>