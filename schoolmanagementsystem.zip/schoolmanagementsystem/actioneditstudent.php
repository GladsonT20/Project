
<div class="contentheader">
<div style=" margin-bottom: 21px;">
<a  href="students.php"><button class="btn btn-default btn-large" style="float: left;"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>
<center><?php
	include('connect.php');
	$stdId=$_GET['stdId'];
	$result = $db->prepare("SELECT * FROM student WHERE stdId= :stdId");
	$result->bindParam(':stdId', $stdId);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveeditstudent.php" method="post" enctype="multipart/form-data">
<center><h4><i class="icon-edit icon-large"></i> Edit Student</h4></center>
<hr>
<div id="ac">
<input type="hidden" name="memi" value="<?php echo $stdId; ?>" />
<span>Reg No. : </span><input type="text" style="width:265px; height:30px;"  name="stdId" value="<?php echo $row['stdId']; ?>" readonly Required/><br>
<span>Full Name : </span><input type="text" style="width:265px; height:30px;"  name="fname" value="<?php echo $row['fname']; ?>" /><br>
<span>Gender: </span>
<select name="gender" style="width:265px; height:30px; margin-left:-5px;" >
	<option><?php echo $row['gender']; ?></option>
	
		<option>Male</option>
		<option>Female</option>
	
</select><br>
<span>D.O.B: </span><input type	="date" style="width:265px; height:30px;" name="dob" value="<?php echo $row['DOB']; ?>" /><br>
<span>Admission Year </span><select name="yoa" style="width:265px; height:30px; margin-left:-5px;" >
	<option><?php echo $row['yoa']; ?></option>
	<option>2009</option>
	<option>2010</option>
	<option>2011</option>
	<option>2012</option>
	<option>2013</option>
	<option>2014</option>
	<option>2015</option>
	<option>2016</option>
	<option>2017</option>
</select><br>
<span>Parent Phone : </span><input type	="text" style="width:265px; height:30px;" value="<?php echo $row['ppn']; ?>" name="ppn" required /><br>
<span>Report : </span><textarea style="width:265px; height:50px;" name="report" ><?php echo $row['report']; ?> </textarea><br><br>

<div >

<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save Changes</button>
</div>
</div>
</form>
<?php
}
?>
</center>

<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
 if(confirm("Sure you want to delete this Student? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deletestudent.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
<?php include('footer.php');?>