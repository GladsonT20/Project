<?php
include('connect.php');
    $id=$_GET['id'];
	$result = $db->prepare("DELETE FROM result WHERE id=:id");
	$result->bindParam(':id', $id);
	$result->execute();
	header("location: mngresult.php");
	//echo $marks;
	?>
