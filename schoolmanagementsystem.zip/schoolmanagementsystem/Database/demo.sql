-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2021 at 10:24 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `classname` varchar(100) NOT NULL,
  `year` varchar(4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `classname`, `year`, `created_at`) VALUES
(2, 'Standard One', '2019', '2021-04-20 14:00:37'),
(6, 'Form Three', '2021', '2021-04-21 16:11:48'),
(7, 'Form One', '2021', '2021-05-12 16:32:07');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `classid` int(11) NOT NULL,
  `stdid` varchar(30) NOT NULL,
  `stubjectid` int(11) NOT NULL,
  `typleofexam` varchar(200) NOT NULL,
  `marks` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `classid`, `stdid`, `stubjectid`, `typleofexam`, `marks`, `created_at`) VALUES
(1, 2, 'D-cab6', 5, 'Terminal', 90, '2021-05-31 11:52:13'),
(2, 2, 'D-cab6', 3, 'Terminal', 90, '2021-06-01 07:15:47');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stdId` varchar(30) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `DOB` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `yoa` int(11) NOT NULL,
  `ppn` varchar(20) NOT NULL,
  `report` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stdId`, `fname`, `DOB`, `gender`, `yoa`, `ppn`, `report`) VALUES
('D-5011', 'Juma Ali', '1998-06-30', 'Male', 2009, '0765572298', 'good '),
('D-9fa7', 'SYLIVESTER MAKAMBU', '2212-12-31', 'Female', 2010, '0712811599', 'eea'),
('D-ac9a', 'Amina', '2007-10-07', 'Female', 2017, '0722333222', 'cool girl'),
('D-cab6', 'siba', '2001-02-05', 'Male', 2009, '0722333222', 'bad boy ');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `stubjectid` int(11) NOT NULL,
  `NameOfSubject` varchar(100) NOT NULL,
  `classid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`stubjectid`, `NameOfSubject`, `classid`) VALUES
(1, 'English', 2),
(2, 'Civics', 2),
(3, 'Geography', 2),
(4, 'Chermisty', 2),
(5, 'Physics', 2),
(6, 'History', 2),
(8, 'Book Keeping', 2),
(9, 'Kiswahili', 2),
(10, 'Chermistry', 6),
(11, 'Mathematics', 6);

-- --------------------------------------------------------

--
-- Table structure for table `tblclasses`
--

CREATE TABLE `tblclasses` (
  `id` int(11) NOT NULL,
  `classid` int(11) NOT NULL,
  `studentid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclasses`
--

INSERT INTO `tblclasses` (`id`, `classid`, `studentid`) VALUES
(38, 7, 'D-9fa7'),
(39, 7, 'D-ac9a'),
(40, 2, 'D-cab6');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(7) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `temail` varchar(100) NOT NULL,
  `education` varchar(100) NOT NULL,
  `EmploymentDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `username`, `fname`, `dob`, `gender`, `phone`, `temail`, `education`, `EmploymentDate`) VALUES
(1, 'Almas', 'Ally J. Almas', '1990-12-01', 'Male', '0712811599', 'makvence@gmail.com', 'Diploma in Primary Education', '2020-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `role`) VALUES
(1, 'siba', '$2y$10$8ajt.msSwISXU7CtqCLRXeij82U.949NTbXT9FVKxcgfHd0cWzzx2', '2021-02-24 09:22:22', 'admin'),
(9, 'gladtim', '$2y$10$0dkJCAhb6slJP60gFFZbgepfyWv49S3iEChJgTLeAziviZv1N6c8y', '2021-05-28 12:52:53', 'teacher');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classid` (`classid`),
  ADD KEY `stubjectid` (`stubjectid`),
  ADD KEY `stdid` (`stdid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stdId`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`stubjectid`),
  ADD KEY `classid` (`classid`);

--
-- Indexes for table `tblclasses`
--
ALTER TABLE `tblclasses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classid` (`classid`),
  ADD KEY `studentid` (`studentid`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `stubjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblclasses`
--
ALTER TABLE `tblclasses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_2` FOREIGN KEY (`classid`) REFERENCES `class` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `result_ibfk_3` FOREIGN KEY (`stubjectid`) REFERENCES `subject` (`stubjectid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `result_ibfk_4` FOREIGN KEY (`stdid`) REFERENCES `student` (`stdId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`classid`) REFERENCES `class` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblclasses`
--
ALTER TABLE `tblclasses`
  ADD CONSTRAINT `tblclasses_ibfk_1` FOREIGN KEY (`classid`) REFERENCES `class` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblclasses_ibfk_2` FOREIGN KEY (`studentid`) REFERENCES `student` (`stdId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
