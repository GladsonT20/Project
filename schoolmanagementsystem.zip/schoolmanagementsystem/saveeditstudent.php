<?php
// configuration
include('connect.php');

// new data
$f = $_POST['stdId'];
$k = $_POST['fname'];
$b = $_POST['report'];
$c = $_POST['yoa'];
$d = $_POST['ppn'];
$e = $_POST['dob'];
$g = $_POST['gender'];
// query

$sql = "UPDATE student 
        SET fname=?, DOB=?, gender=?, yoa=?, ppn=?, report=?    
		WHERE stdId=?";
$q = $db->prepare($sql);
$q->execute(array($k, $e, $g, $c, $d, $b, $f));
header("location: students.php");

?>