<?php
include('connect.php');
    $id=$_GET['stdid'];
	$result = $db->prepare("DELETE FROM result WHERE stdid=:id");
	$result->bindParam(':id', $id);
	$result->execute();
	header("location: mngresult.php");
	//echo $marks;
	?>