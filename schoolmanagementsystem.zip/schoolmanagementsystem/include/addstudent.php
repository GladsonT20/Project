      <form action="savestudent.php" method="post" enctype="multipart/form-data">
        <center><h4><i class="icon-edit icon-large"></i> Add New Student	</h4></center>
        <hr><center>
          <div id="ac">
            <span>Student ID: </span><input type="text" style="width:265px; height:30px;"  value="D-<?php 
            $prefix= md5(time()*rand(1, 2)); echo strip_tags(substr($prefix ,0,4));?>" name="stdId" readonly Required /><br>
            <span>First Name : </span><input type="text" style="width:265px; height:30px;"  name="fname" Required /><br>
            <span>Middle Name : </span><input type="text" style="width:265px; height:30px;"  name="mname" Required /><br>
            <span>Last Name : </span><input type="text" style="width:265px; height:30px;"  name="lname" Required /><br>
            <span>Gender: </span>
            <select name="gender" style="width:265px; height:30px; margin-left:-5px;" >
             <option>Female</option>
             <option>Male</option>
           </select><br>
           <span>D.O.B: </span><input type	="date" style="width:265px; height:30px;" name="dob" required /><br>
           <span>Admission Year </span><select name="yoa" style="width:265px; height:30px; margin-left:-5px;" >
             <option>2009</option>
             <option>2010</option>
             <option>2011</option>
             <option>2012</option>
             <option>2013</option>
             <option>2014</option>
             <option>2015</option>
             <option>2016</option>
             <option>2017</option>
           </select><br>
           <span>Parent Phone: </span><input type	="text" style="width:265px; height:30px;" name="ppn" required />
           <br>
           <span>Report : </span><textarea style="width:265px; height:50px;" name="report" ></textarea><br>
           <div >

            <button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save Student</button>
          </div>
        </div></center>
      </form>
    

    <script src="../js/jquery.js"></script>
    <script type="text/javascript">
      $(function() {


        $(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
if(confirm("Sure you want to delete this Student? There is NO undo!"))
{

 $.ajax({
   type: "GET",
   url: "deletestudent.php",
   data: info,
   success: function(){
     
   }
 });
 $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
 .animate({ opacity: "hide" }, "slow");

}

return false;

});

      });
    </script>
  <?php include('../footer.php');?>