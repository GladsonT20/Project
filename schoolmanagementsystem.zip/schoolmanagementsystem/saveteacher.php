<?php
session_start();
include('connect.php');
$a = $_POST['fname'];
$k = $_POST['lname'];
$e = $_POST['dob'];
$f = $_POST['teacherlevel'];
$c = $_POST['gender'];
$d = $_POST['teacherphone'];
$j = $_POST['temail'];
$m = $_POST['empydate'];

// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO teachers (fname,lname,dob,gender,phone,temail,education,EmploymentDate) VALUES (:a,:k,:e,:c,:d,:j :f,:m)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':k'=>$k,':e'=>$e,':c'=>$c,':d'=>$d,':j'=>$j,':f'=>$f,':m'=>$m));
header("location: welcome.php");

	//}


?>