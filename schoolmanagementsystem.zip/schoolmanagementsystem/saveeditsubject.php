<?php
// configuration
include('connect.php');

// update data
$f = $_POST['code'];
$k = $_POST['subject'];
$a = $_POST['classname'];
$h = $_POST['subjectteacher'];
//$b = $_POST['report'];
//$c = $_POST['yoa'];
//$d = $_POST['ppn'];
//$e = $_POST['dob'];
//$g = $_POST['gender'];
// query

$sql = "UPDATE subject 
        SET NameOfSubject=?, class=?, teacher=?    
		WHERE Code=?";
$q = $db->prepare($sql);
$q->execute(array($k, $a, $h, $f));
header("location: teachers.php");
?>