        <div style="background-color: #7386D5; height: 50px; margin:0;">
          <a class="brand" href="#" style="font-size: 30px;"><b>Student Record Management System </b></a>
        </div>