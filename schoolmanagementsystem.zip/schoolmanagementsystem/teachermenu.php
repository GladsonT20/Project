<div class="sidenav">
   <a class="dropdown-btn" href="home.php"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;HOME&nbsp;&nbsp;</a>
  <br>
  <button class="dropdown-btn"><i class="menu-icon fa fa-th"></i>&nbsp;STUDENTS
  </button>
  <div class="dropdown-container">
    <a href="addstudent.php">Add</a>
    <a href="students.php">Manage</a>
  </div>
  <button class="dropdown-btn"><i class="menu-icon fa fa-th"></i>&nbsp;RESULT
  </button>
  <div class="dropdown-container">
    <a href="result.php">Add</a>
    <a href="mngresult.php">Manage</a>
  </div>
  <button class="dropdown-btn">HELP
  </button>
</div>
