<?php
session_start();
include('connect.php');
$k = $_SESSION["username"];
$a = $_POST['fname'];
$e = $_POST['dob'];
$f = $_POST['teacherlevel'];
$c = $_POST['gender'];
$d = $_POST['teacherphone'];
$j = $_POST['temail'];
$m = $_POST['empydate'];

// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO teachers (username,fname,dob,gender,phone,temail,education,EmploymentDate) VALUES (:k,:a,:e,:c,:d,:j,:f,:m)";
$q = $db->prepare($sql);
$q->execute(array(':k'=>$k,':a'=>$a,':e'=>$e,':c'=>$c,':d'=>$d,':j'=>$j,':f'=>$f,':m'=>$m));
header("location: welcome.php");

	//}


?>