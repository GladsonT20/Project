<?php
	include('connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("DELETE FROM teachers WHERE id= :id");
	$result->bindParam(':id', $id);
	$result->execute();
	
	header ("location: teachers.php");
?>