<?php
session_start();
include('connect.php');
$ci = $_SESSION['id'];
$si = $_POST['stubjectid'];
$sti = $_POST['studentid'];
$et = $_POST['examtype'];
$m = $_POST['marks'];
// query
  //do your write to the database filename and other details   
$sql = "INSERT INTO result (classid, stdid, stubjectid, typleofexam, marks) VALUES (:ci, :sti, :si,:et, :m)";
$q = $db->prepare($sql);
$q->execute(array(':ci'=>$ci,':sti'=>$sti,':si'=>$si,':et'=>$et,':m'=>$m));
header("location: result.php");

	//}


?>