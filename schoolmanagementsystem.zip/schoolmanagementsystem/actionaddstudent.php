<div class="container-fluid">
<div class="row-fluid">
    <div class="span10">
      <form action="savestudent.php" method="post" enctype="multipart/form-data">
        <center><h4><i class="icon-edit icon-large"></i> Add New Student	</h4></center>
        <hr><center>
          <div id="ac">
            <span>Student ID: </span><input type="text" style="width:265px; height:30px;"  value="D-<?php 
            $prefix= md5(time()*rand(1, 2)); echo strip_tags(substr($prefix ,0,4));?>" name="stdId" readonly Required /><br>
            <span>Full Name : </span><input type="text" style="width:265px; height:30px;"  name="fname" Required /><br>
            <span>Gender: </span>
            <select name="gender" style="width:265px; height:30px; margin-left:-5px;" required >
              <option value="">Choose..</option>
             <option value="Female">Female</option>
             <option value="Male">Male</option>
           </select><br>
           <span>D.O.B: </span><input type	="date" style="width:265px; height:30px;" name="dob" required /><br>
           <span>Admission Year </span><select name="yoa" style="width:265px; height:30px; margin-left:-5px;" required>
            <option value="" >Choose Year..</option>
             <option value="2009" >2009</option>
             <option value="2010">2010</option>
             <option value="2011">2011</option>
             <option value="2012">2012</option>
             <option value="2013">2013</option>
             <option value="2014">2014</option>
             <option value="2015">2015</option>
             <option value="2016">2016</option>
             <option value="2017">2017</option>
           </select><br>
           <span>Parent Phone: </span><input type	="text" style="width:265px; height:30px;" name="ppn" required />
           <br>
           <span>Report : </span><textarea style="width:265px; height:50px;" name="report" ></textarea><br>
           <div >

            <button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save Student</button>
          </div>
        </div></center>
      </form>
    </div>
  </div>
</div>
    

    <script src="js/jquery.js"></script>
    <script type="text/javascript">
      $(function() {


        $(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
if(confirm("Sure you want to delete this Student? There is NO undo!"))
{

 $.ajax({
   type: "GET",
   url: "deletestudent.php",
   data: info,
   success: function(){
     
   }
 });
 $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
 .animate({ opacity: "hide" }, "slow");

}

return false;

});

      });
    </script>
  <?php include('footer.php');?>