<?php
session_start();
if (empty($_POST['rid'])) {
  header("Location: prntviews.php");
die();
  }
  $id=$_POST['rid'];
include('connect.php');
$b=$_SESSION['regnumber'];
//------------student information---------
 $resultst= $db->prepare("SELECT * FROM student WHERE stdId='$b'");
 $resultst->execute();
 $rowst = $resultst->fetch();
//---------------------from post-----------
 $resulty= $db->prepare("SELECT classid, typleofexam FROM result WHERE id='$id'");
 $resulty->execute();
 $rowy = $resulty->fetch();
 $cid=$rowy['classid'];
 $typeofexam=$rowy['typleofexam'];
 //--------------class name-------------
  $resultc= $db->prepare("SELECT classname, year FROM class WHERE id='$cid'");
 $resultc->execute();
 $rowc = $resultc->fetch();
 $classname = $rowc['classname'];
 $cyear = $rowc['year'];
         
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>SAMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/4.3.1/flatly/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-sidermenu.css" />

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="js/bootstrap-sidermenu.js"></script>
    <style>
      body { background-color: #f7f7f7; }
      input[type=text] {
    padding:5px; 
    border:2px solid #ccc; 
    -webkit-border-radius: 5px;
    border-radius: 5px;
    width: 100%;
}

input[type=text]:focus {
    border-color:#333;
}

input[type=submit] {
    padding:5px 15px; 
    background:#ccc; 
    border:0 none;
    cursor:pointer;
    -webkit-border-radius: 5px;
    border-radius: 5px; 
}
    </style>
  </head>
  <body">
    <nav class="navbar navbar-dark bg-dark">
      <p style="font-size: 35px;">Student Academic Management System [SAMS]</p>
    </nav>
        <div class="container" style="margin-top: 10%;">
          <center>

            <br>
            <table id="printTable">
             <tr>
               <td colspan="4" style="font-size: 18px; font-weight: bold;">Academic Report </td>
             </tr>
             <tr>
              <td colspan="4" style="font-size: 18px; font-weight: bold;"><?php echo $classname; ?>-<?php echo $typeofexam; ?> Result.</td>
             </tr>
              <tr>
                <td colspan="4">Student Name:&nbsp;<span style="text-transform: uppercase;"><?php echo  $rowst['fname'];?></span></td>
              </tr>
              <tr>
                <td colspan="2">Gender:&nbsp;<span style="text-transform: uppercase;"><?php echo  $rowst['gender'];?></span></td>
              </tr>
              <tr>
                <td colspan="2">Year of Admission:&nbsp;<span style="text-transform: uppercase;"><?php echo  $rowst['yoa'];?></span></td>
              </tr>
              <tr>
                <th>#</th>
                <th>Subject</th>
                <th>Mark</th>
                <th>Remark</th>
              </tr>
              <?php
              $resultm = $db->prepare("SELECT subject.NameOfSubject, result.marks FROM result INNER JOIN subject on result.stubjectid=subject.stubjectid WHERE result.classid='$cid' AND result.stdid='$b' AND result.typleofexam='$typeofexam'");
             //$result->bindParam(':id', $m);
             $resultm->execute();
         for($i=1; $rowresult= $resultm->fetch(); $i++)
            { 
              echo "<tr>";
              echo "<td>".$i."</td>";
              echo "<td>";
              echo $rowresult['NameOfSubject'];
              echo "</td>";
              echo "<td>".$rowresult['marks']."</td>";
              if($rowresult['marks'] >= 81){
                 echo "<td style='text-align:right;'>A</td>";
            }elseif ($rowresult['marks']>=61 && $rowresult['marks']<=80) {
               echo "<td style='text-align:right;'>B</td>";
            }
            elseif ($rowresult['marks']>=41 && $rowresult['marks']<=60) {
               echo "<td style='text-align:right;'>C</td>";
            }
            elseif ($rowresult['marks']>=31 && $rowresult['marks']<=40) {
               echo "<td style='text-align:right;'>D</td>";
            }
            elseif ($rowresult['marks']>=21 && $rowresult['marks']<=30) {
               echo "<td style='text-align:right;'>E</td>";
            }
            elseif ($rowresult['marks']<=20) {
               echo "<td style='text-align:right;'>F</td>";
            }
              echo "</tr>";
            }
            $resultg = $db->prepare("SELECT SUM(result.marks) as totalmark FROM result INNER JOIN subject on result.stubjectid=subject.stubjectid WHERE result.classid='$cid' AND result.stdid='$b' AND result.typleofexam='$typeofexam'");
             $resultg->execute();
             $rowt = $resultg->fetch(PDO::FETCH_ASSOC);
             echo "<tr><td colspan='2'><b>Total Marks:</b></td>";
             echo "<td colspan='2'>";
             echo $rowt['totalmark'];
             echo "</td></tr>";
              
              $resulta = $db->prepare("SELECT ROUND(AVG(result.marks), 1) as aver FROM result INNER JOIN subject on result.stubjectid=subject.stubjectid WHERE result.classid='$cid' AND result.stdid='$b' AND result.typleofexam='$typeofexam'");
             $resulta->execute();
             $rowa = $resulta->fetch(PDO::FETCH_ASSOC);
             echo "<tr><td colspan='2'><b>Average:</b></td>";
             echo "<td>";
             echo $rowa['aver']."%";
             echo "</td>";
             if($rowa['aver'] >= 81){
                 echo "<td style='text-align:right;'>A</td>";
            }elseif ($rowa['aver']>=61 && $rowa['aver']<=80) {
               echo "<td>B</td>";
            }
            elseif ($rowa['aver']>=41 && $rowa['aver']<=60) {
               echo "<td>C</td>";
            }
            elseif ($rowa['aver']>=31 && $rowa['aver']<=40) {
               echo "<td>D</td>";
            }
            elseif ($rowa['aver']>=21 && $rowa['aver']<=30) {
               echo "<td>E</td>";
            }
            elseif ($rowa['aver']<=20) {
               echo "<td>F</td>";
            }


             echo"</tr>";
             ?>

            </table>
            <button onclick="printData()">Print</button>
<script type="text/javascript">
  function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}
</script>
           <button type="cancel" onclick="window.location='prntviews.php';return false;">Close</button>
          </center>
        </div>
      </div>
    </div>
  </body>
</html>
